[
  {
    "_id": "07e40c5d5b9d552b83d9082e6001e76f",
    "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
    "nombre": "sandalia",
    "avillos": [
      {
        "_id": "07e40c5d5b9d552b83d9082e6000a52a",
        "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
        "nombre": "durasno para plantilla",
        "cantidad": "0.0526",
        "cantidadInicial": "19",
        "unidad": {
          "nombre": "yardas",
          "conversiones": [
            {
              "nombre": "pares en yardas",
              "constante": null
            },
            {
              "nombre": "centimetros",
              "constante": 0.010936132983377079
            },
            {
              "nombre": "pulgadas",
              "constante": 0.027777777777777776
            }
          ]
        },
        "colorSegunMaterial": true,
        "unidadConversion": {
          "nombre": "pares en yardas",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
        "_rev": "1-33358ec4023550fa089677837aa750b0",
        "nombre": "carton con eva",
        "cantidad": "0.0286",
        "cantidadInicial": "35",
        "unidad": {
          "nombre": "pliegos",
          "conversiones": [
            {
              "nombre": "pares en pliego",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en pliego",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
        "nombre": "pega amarilla",
        "cantidad": "0.0100",
        "cantidadInicial": "100",
        "unidad": {
          "nombre": "galones",
          "conversiones": [
            {
              "nombre": "pares en galon",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en galon",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      }
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001e9b3",
    "_rev": "3-dba13acda20fc93be941d08be2664af6",
    "nombre": "tacon",
    "avillos": [
      {
        "_id": "07e40c5d5b9d552b83d9082e6000a52a",
        "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
        "nombre": "durasno para plantilla",
        "cantidad": "0.0667",
        "cantidadInicial": "15",
        "unidad": {
          "nombre": "yardas",
          "conversiones": [
            {
              "nombre": "pares en yardas",
              "constante": null
            },
            {
              "nombre": "centimetros",
              "constante": 0.010936132983377079
            },
            {
              "nombre": "pulgadas",
              "constante": 0.027777777777777776
            }
          ]
        },
        "colorSegunMaterial": true,
        "unidadConversion": {
          "nombre": "pares en yardas",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
        "nombre": "royalty 600",
        "cantidad": "0.0167",
        "cantidadInicial": "60",
        "unidad": {
          "nombre": "pliegos",
          "conversiones": [
            {
              "nombre": "pares en pliego",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en pliego",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
        "_rev": "1-33358ec4023550fa089677837aa750b0",
        "nombre": "carton con eva",
        "cantidad": "0.0286",
        "cantidadInicial": "35",
        "unidad": {
          "nombre": "pliegos",
          "conversiones": [
            {
              "nombre": "pares en pliego",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en pliego",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
        "nombre": "pega amarilla",
        "cantidad": "0.0100",
        "cantidadInicial": "100",
        "unidad": {
          "nombre": "galones",
          "conversiones": [
            {
              "nombre": "pares en galon",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en galon",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000fc42",
        "_rev": "1-1fe631135331b07e429008a6e292ed7c",
        "nombre": "forro perla",
        "cantidad": "0.0147",
        "cantidadInicial": "68",
        "unidad": {
          "nombre": "yardas",
          "conversiones": [
            {
              "nombre": "pares en yardas",
              "constante": null
            },
            {
              "nombre": "centimetros",
              "constante": 0.010936132983377079
            },
            {
              "nombre": "pulgadas",
              "constante": 0.027777777777777776
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en yardas",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e60010794",
        "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
        "nombre": "carton piedra",
        "cantidad": "0.0147",
        "cantidadInicial": "68",
        "unidad": {
          "nombre": "pliegos",
          "conversiones": [
            {
              "nombre": "pares en pliego",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en pliego",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": true
      }
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
    "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
    "nombre": "china",
    "avillos": [
      {
        "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
        "_rev": "1-33358ec4023550fa089677837aa750b0",
        "nombre": "carton con eva",
        "cantidad": "0.0286",
        "cantidadInicial": "35",
        "unidad": {
          "nombre": "pliegos",
          "conversiones": [
            {
              "nombre": "pares en pliego",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en pliego",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
        "nombre": "pega amarilla",
        "cantidad": "0.0100",
        "cantidadInicial": "100",
        "unidad": {
          "nombre": "galones",
          "conversiones": [
            {
              "nombre": "pares en galon",
              "constante": null
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en galon",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e6000fc42",
        "_rev": "1-1fe631135331b07e429008a6e292ed7c",
        "nombre": "forro perla",
        "cantidad": "0.0286",
        "cantidadInicial": "35",
        "unidad": {
          "nombre": "yardas",
          "conversiones": [
            {
              "nombre": "pares en yardas",
              "constante": null
            },
            {
              "nombre": "centimetros",
              "constante": 0.010936132983377079
            },
            {
              "nombre": "pulgadas",
              "constante": 0.027777777777777776
            }
          ]
        },
        "colorSegunMaterial": false,
        "unidadConversion": {
          "nombre": "pares en yardas",
          "constante": null
        },
        "predeterminado": false,
        "paraTacon": false
      }
    ]
  }
]