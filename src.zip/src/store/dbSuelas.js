[
    {
        "_id": "07e40c5d5b9d552b83d9082e60022571",
        "_rev": "1-630c1ba05ac22d2320cf630713e16df0",
        "nombre": "3239",
        "defaultColor": null,
        "colores": []
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e60022b3c",
        "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
        "nombre": "1158",
        "defaultColor": "crema",
        "colores": [
          "crema",
          "gun",
          "negro"
        ]
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e60022d66",
        "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
        "nombre": "1122",
        "defaultColor": "negro",
        "colores": [
          "negro",
          "gun"
        ]
      },
      {
        "_id": "07e40c5d5b9d552b83d9082e600235da",
        "_rev": "1-aa4b98ebfa2a01e595833662a143f6cd",
        "nombre": "sueleta",
        "defaultColor": "negro",
        "colores": [
          "negro",
          "gun"
        ]
      }
]