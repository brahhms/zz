const authentication = {
    auth: {
        username: 'admin',
        password: 'admin'
    },
    headers:{'Content-Type': 'application/json; charset=utf-8'}
};
 
export default {
    authentication,
}