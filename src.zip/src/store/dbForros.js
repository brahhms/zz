[
  {
    "_id": "07e40c5d5b9d552b83d9082e60018d89",
    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
    "nombre": "perla",
    "defaultColor": "perla",
    "colores": [
      "perla"
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e60019c69",
    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
    "nombre": "tricoth",
    "defaultColor": "gris",
    "colores": [
      "negro",
      "gris",
      "beige"
    ]
  }
]