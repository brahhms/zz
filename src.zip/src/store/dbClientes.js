[
  {
    "_id": "07e40c5d5b9d552b83d9082e6001634b",
    "_rev": "1-4dddc718792e57cfbb733a95db780982",
    "nombre": "mama",
    "codigoPais": null,
    "telefono": null,
    "direccion": "Candelaria de la Frontera",
    "documento": null
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e600172a1",
    "_rev": "1-ba42e2992f145ec7467918afcc4e173d",
    "nombre": "dona angelica plaza",
    "direccion": "Guatemala, Guatemala"
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e60017665",
    "_rev": "1-b6c458f896adcbe8a93f616bd197f8ff",
    "nombre": "iman MC",
    "direccion": "Guatemala, Guatemala"
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e60018546",
    "_rev": "1-501a0232d811a12beead3678bf9227c3",
    "nombre": "sandra vazquez",
    "direccion": "Totonicapan, Guatemala"
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e600188e1",
    "_rev": "1-feaa76e7afea0cbf6b3e671db25c5986",
    "nombre": "mario gomez",
    "direccion": "Xela, Guatemala"
  }
]