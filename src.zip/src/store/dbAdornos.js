[{
  "_id": "07e40c5d5b9d552b83d9082e60002423",
  "_rev": "1-4653b8e5df519330876484553e8316c0",
  "nombre": "punteras R96",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e60003086",
  "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
  "nombre": "punteras R120",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e6000351d",
  "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
  "nombre": "flor R122",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600041ec",
  "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
  "nombre": "girasol con repollo",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e60004fda",
  "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
  "nombre": "remache 1,000",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": false,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600052b5",
  "_rev": "1-8a10f6721a7daaff28879c2a83358145",
  "nombre": "perlas remaches",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": false,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e6000560a",
  "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
  "nombre": "evillas de 3 puntos",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": false,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e6000606d",
  "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
  "nombre": "punteras R121",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e60006ece",
  "_rev": "1-7dd59c57c369802e3413387aa110e28d",
  "nombre": "flor con repollo R123",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e6000750d",
  "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
  "nombre": "flores de ojitas",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600079c9",
  "_rev": "1-59b03814471dda8b230288993f3c1021",
  "nombre": "punteras R119",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600083fe",
  "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
  "nombre": "elastico",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "yardas",
    "conversiones": [
      {
        "nombre": "yardas",
        "constante": 1
      },
      {
        "nombre": "centimetros",
        "constante": 0.010936132983377079
      },
      {
        "nombre": "pulgadas",
        "constante": 0.027777777777777776
      }
    ]
  },
  "unidadConversion": {
    "nombre": "yardas",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600088d6",
  "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
  "nombre": "remaches diamantes",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": false,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e600088e2",
  "_rev": "2-4da34413925938ff509a1c81f908bc1b",
  "nombre": "cola de raton",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "yardas",
    "conversiones": [
      {
        "nombre": "yardas",
        "constante": 1
      },
      {
        "nombre": "centimetros",
        "constante": 0.010936132983377079
      },
      {
        "nombre": "pulgadas",
        "constante": 0.027777777777777776
      }
    ]
  },
  "unidadConversion": {
    "nombre": "yardas",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e60008deb",
  "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
  "nombre": "chonga R124",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
},
{
  "_id": "07e40c5d5b9d552b83d9082e6000955a",
  "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
  "nombre": "punteras R95",
  "cantidad": 0,
  "cantidadInicial": 0,
  "colorSegunMaterial": true,
  "unidad": {
    "nombre": "pares",
    "conversiones": [
      {
        "nombre": "pares",
        "constante": 1
      }
    ]
  },
  "unidadConversion": {
    "nombre": "pares",
    "constante": 1
  }
}

]
