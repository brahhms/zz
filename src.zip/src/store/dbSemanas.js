[
    {
        "_id": "07e40c5d5b9d552b83d9082e6002ac00",
        "_rev": "6-66c02f2f7a2b9ad925a587e26202d82b",
        "semana": 17,
        "color": "blue",
        "siguienteSemana": 18,
        "ano": 2021,
        "fecha": "2021-04-26T06:00:00.000Z",
        "pedidos": [
          {
            "_id": "pedido-540963",
            "cliente": {
              "_id": "07e40c5d5b9d552b83d9082e600172a1",
              "_rev": "1-ba42e2992f145ec7467918afcc4e173d",
              "nombre": "dona angelica plaza",
              "direccion": "Guatemala, Guatemala"
            },
            "ano": 2021,
            "fecha": "2021-04-26T06:00:00.000Z",
            "semana": 17,
            "siguienteSemana": 18,
            "detalle": [
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60026a63",
                  "_rev": "1-16fb7bae78c1c1652bb92f344b519a11",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 96,
                  "codigo": "R96",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": "0.0000",
                      "cantidadInicial": "0",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "beige"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 5
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "gun"
                },
                "subtotal": 36
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60026a63",
                  "_rev": "1-16fb7bae78c1c1652bb92f344b519a11",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 96,
                  "codigo": "R96",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": "0.0000",
                      "cantidadInicial": "0",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 10
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 10
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 10
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 5
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 43
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60026f97",
                  "_rev": "1-410a24311791ab704f6d7e1cc7e1151f",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 120,
                  "codigo": "R120",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 10
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60026f97",
                  "_rev": "1-410a24311791ab704f6d7e1cc7e1151f",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 120,
                  "codigo": "R120",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "rosa vieja"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "gun"
                },
                "subtotal": 12
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60027aec",
                  "_rev": "1-966e6bc94c022e8e05f0d64c8543c5c0",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 122,
                  "codigo": "R122",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 2
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 20
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60027aec",
                  "_rev": "1-966e6bc94c022e8e05f0d64c8543c5c0",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 122,
                  "codigo": "R122",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "gena"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 5
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 5
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 14
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60029f0a",
                  "_rev": "1-f2fb325f165574be5ecefe3dad4d3982",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6002059d",
                    "_rev": "1-b0ee9c6c8ec55962340bcbe423a78cd9",
                    "nombre": "TA",
                    "tacon": true,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e9b3",
                      "_rev": "3-dba13acda20fc93be941d08be2664af6",
                      "nombre": "tacon",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0667",
                          "cantidadInicial": "15",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                          "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                          "nombre": "royalty 600",
                          "cantidad": "0.0167",
                          "cantidadInicial": "60",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0147",
                          "cantidadInicial": "68",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e60010794",
                          "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
                          "nombre": "carton piedra",
                          "cantidad": "0.0147",
                          "cantidadInicial": "68",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": true
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b816",
                        "_rev": "1-147a9edcb038d1a6fd001b2a39bb37ec",
                        "nombre": "royalty 1000",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d246",
                        "_rev": "1-3f6ca847b1131b810c2c11f8fc8da036",
                        "nombre": "cambrellon",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                        "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                        "nombre": "evilla de 3 puntos",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                        "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                        "nombre": "remaches diamantes",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000defb",
                        "_rev": "1-890f492f77d85a13402bd42976ce3551",
                        "nombre": "remaches",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60010bfb",
                        "_rev": "1-d88ab51277194072cce9b610851757c7",
                        "nombre": "tacon",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60010c3e",
                        "_rev": "1-2655b2040186d6a61753daa920d52284",
                        "nombre": "tornillo",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      }
                    ]
                  },
                  "correlativo": 19,
                  "codigo": "TA19",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b816",
                      "_rev": "1-147a9edcb038d1a6fd001b2a39bb37ec",
                      "nombre": "royalty 1000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d246",
                      "_rev": "1-3f6ca847b1131b810c2c11f8fc8da036",
                      "nombre": "cambrellon",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                      "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                      "nombre": "evilla de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                      "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000defb",
                      "_rev": "1-890f492f77d85a13402bd42976ce3551",
                      "nombre": "remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010794",
                      "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
                      "nombre": "carton piedra",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010bfb",
                      "_rev": "1-d88ab51277194072cce9b610851757c7",
                      "nombre": "tacon",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010c3e",
                      "_rev": "1-2655b2040186d6a61753daa920d52284",
                      "nombre": "tornillo",
                      "cantidad": "2.0000",
                      "cantidadInicial": "2",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro",
                  "cantidad": 0.1
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001c91b",
                  "_rev": "2-3078117e56e48ef437288597b425ea86",
                  "nombre": "plataforma 3152",
                  "paraTacon": true
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e600235da",
                    "_rev": "1-aa4b98ebfa2a01e595833662a143f6cd",
                    "nombre": "sueleta",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 14
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60029f58",
                  "_rev": "1-5a87ce0cb4066c26b206ccd7bca56cb4",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6002059d",
                    "_rev": "1-b0ee9c6c8ec55962340bcbe423a78cd9",
                    "nombre": "TA",
                    "tacon": true,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e9b3",
                      "_rev": "3-dba13acda20fc93be941d08be2664af6",
                      "nombre": "tacon",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0667",
                          "cantidadInicial": "15",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                          "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                          "nombre": "royalty 600",
                          "cantidad": "0.0167",
                          "cantidadInicial": "60",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0147",
                          "cantidadInicial": "68",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e60010794",
                          "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
                          "nombre": "carton piedra",
                          "cantidad": "0.0147",
                          "cantidadInicial": "68",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": true
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b816",
                        "_rev": "1-147a9edcb038d1a6fd001b2a39bb37ec",
                        "nombre": "royalty 1000",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d246",
                        "_rev": "1-3f6ca847b1131b810c2c11f8fc8da036",
                        "nombre": "cambrellon",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                        "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                        "nombre": "evilla de 3 puntos",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                        "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                        "nombre": "remaches diamantes",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000defb",
                        "_rev": "1-890f492f77d85a13402bd42976ce3551",
                        "nombre": "remaches",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60010bfb",
                        "_rev": "1-d88ab51277194072cce9b610851757c7",
                        "nombre": "tacon",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60010c3e",
                        "_rev": "1-2655b2040186d6a61753daa920d52284",
                        "nombre": "tornillo",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": true
                      }
                    ]
                  },
                  "correlativo": 23,
                  "codigo": "TA23",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b816",
                      "_rev": "1-147a9edcb038d1a6fd001b2a39bb37ec",
                      "nombre": "royalty 1000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d246",
                      "_rev": "1-3f6ca847b1131b810c2c11f8fc8da036",
                      "nombre": "cambrellon",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                      "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                      "nombre": "evilla de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                      "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000defb",
                      "_rev": "1-890f492f77d85a13402bd42976ce3551",
                      "nombre": "remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010794",
                      "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
                      "nombre": "carton piedra",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010bfb",
                      "_rev": "1-d88ab51277194072cce9b610851757c7",
                      "nombre": "tacon",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60010c3e",
                      "_rev": "1-2655b2040186d6a61753daa920d52284",
                      "nombre": "tornillo",
                      "cantidad": "2.0000",
                      "cantidadInicial": "2",
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": true
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro",
                  "cantidad": 0.1
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001c91b",
                  "_rev": "2-3078117e56e48ef437288597b425ea86",
                  "nombre": "plataforma 3152",
                  "paraTacon": true
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e600235da",
                    "_rev": "1-aa4b98ebfa2a01e595833662a143f6cd",
                    "nombre": "sueleta",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 13
              }
            ],
            "isEditing": false,
            "isMoving": false,
            "total": 162
          },
          {
            "_id": "pedido-424267",
            "cliente": {
              "_id": "07e40c5d5b9d552b83d9082e6001634b",
              "_rev": "1-4dddc718792e57cfbb733a95db780982",
              "nombre": "mama",
              "codigoPais": null,
              "telefono": null,
              "direccion": "Candelaria de la Frontera",
              "documento": null
            },
            "ano": 2021,
            "fecha": "2021-04-26T06:00:00.000Z",
            "semana": 17,
            "siguienteSemana": 18,
            "detalle": [
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002b80f",
                  "_rev": "1-eddfdda2fc8005ba571683124242851c",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 2000,
                  "codigo": "S2000",
                  "rendimientoMaterial": "0.0833",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": "3.0000",
                      "cantidadInicial": "3",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "gena"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 1
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 11
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002b80f",
                  "_rev": "1-eddfdda2fc8005ba571683124242851c",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 2000,
                  "codigo": "S2000",
                  "rendimientoMaterial": "0.0833",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": "3.0000",
                      "cantidadInicial": "3",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 1
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 11
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60023e70",
                  "_rev": "1-0f59b407b7a4b5cc3c0d9c193bb2b521",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 75,
                  "codigo": "S75",
                  "rendimientoMaterial": "0.0500",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0500",
                      "cantidadInicial": "20",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": "0.3062",
                      "cantidadInicial": "28",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 1
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 13
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60024518",
                  "_rev": "1-91255f12223d4954b80e0d54ed500fc4",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f81d",
                    "_rev": "1-c51fabae3f1875607f1e778e1cdbf6a1",
                    "nombre": "BP",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                        "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                        "nombre": "durasno para plantilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": true,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                        "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                        "nombre": "evilla de 3 puntos",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                        "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                        "nombre": "remaches diamantes",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000defb",
                        "_rev": "1-890f492f77d85a13402bd42976ce3551",
                        "nombre": "remaches",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pares",
                          "conversiones": [
                            {
                              "nombre": "pares",
                              "constante": 1
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares",
                          "constante": 1
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 6,
                  "codigo": "BP6",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.0909",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                      "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                      "nombre": "durasno para plantilla",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": true,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d58c",
                      "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
                      "nombre": "evilla de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000d78b",
                      "_rev": "1-78ce08246d79ba4087883f4efb7cb496",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000defb",
                      "_rev": "1-890f492f77d85a13402bd42976ce3551",
                      "nombre": "remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 4
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002810a",
                  "_rev": "1-63617b955890fc836c9f2e9a1c5ea836",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 186,
                  "codigo": "R186",
                  "rendimientoMaterial": "0.0909",
                  "rendimientoForro": "0.0909",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0286",
                      "cantidadInicial": "35",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ca8e",
                    "_rev": "1-3457f600e12e510d240b3eae4a4b7c49",
                    "nombre": "charol",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "corinto",
                      "rosa vieja",
                      "azul",
                      "rojo"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 4
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 17
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60028b7c",
                  "_rev": "1-098a94c1ebac24d6c1d0b67f35c17411",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 90,
                  "codigo": "R90",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0286",
                      "cantidadInicial": "35",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.9685",
                      "cantidadInicial": "180",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 1
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 12
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002c67b",
                  "_rev": "1-c7c7c2f2f8ef7b45af508cee8f1b3e4a",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 1000,
                  "codigo": "S1000",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.1250",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": "3.0000",
                      "cantidadInicial": "3",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": "5.0000",
                      "cantidadInicial": "5",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 13
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002c67b",
                  "_rev": "1-c7c7c2f2f8ef7b45af508cee8f1b3e4a",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 1000,
                  "codigo": "S1000",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.1250",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": "3.0000",
                      "cantidadInicial": "3",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": "5.0000",
                      "cantidadInicial": "5",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "rosado"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 5
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e6002c67b",
                  "_rev": "1-c7c7c2f2f8ef7b45af508cee8f1b3e4a",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001f2f6",
                    "_rev": "1-b6500e1fb3d50b2a76bb8483ca27da31",
                    "nombre": "S",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001e76f",
                      "_rev": "1-e8ffd7a120118e9569f338789c09ca28",
                      "nombre": "sandalia",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000a52a",
                          "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
                          "nombre": "durasno para plantilla",
                          "cantidad": "0.0526",
                          "cantidadInicial": "19",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": true,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 1000,
                  "codigo": "S1000",
                  "rendimientoMaterial": "0.1250",
                  "rendimientoForro": "0.1250",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": "3.0000",
                      "cantidadInicial": "3",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": "5.0000",
                      "cantidadInicial": "5",
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001e681",
                    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                    "nombre": "pu",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "beige",
                      "corinto",
                      "rosado"
                    ]
                  },
                  "color": "corinto"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 1
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
                  "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
                  "nombre": "sandalia",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60018d89",
                    "_rev": "1-916c4ec1b0db6747c21a841c67089a51",
                    "nombre": "perla",
                    "defaultColor": "perla",
                    "colores": [
                      "perla"
                    ]
                  },
                  "color": "perla"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022b3c",
                    "_rev": "2-e56ff6c27c0f3f018a91647004918e4a",
                    "nombre": "1158",
                    "defaultColor": "crema",
                    "colores": [
                      "crema",
                      "gun",
                      "negro"
                    ]
                  },
                  "color": "crema"
                },
                "subtotal": 4
              }
            ],
            "isEditing": false,
            "isMoving": false,
            "total": 90
          },
          {
            "_id": "pedido-965408",
            "cliente": {
              "_id": "07e40c5d5b9d552b83d9082e60017665",
              "_rev": "1-b6c458f896adcbe8a93f616bd197f8ff",
              "nombre": "iman MC",
              "direccion": "Guatemala, Guatemala"
            },
            "ano": 2021,
            "fecha": "2021-04-26T06:00:00.000Z",
            "semana": 17,
            "siguienteSemana": 18,
            "detalle": [
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60025aad",
                  "_rev": "1-76da527c88cf210c0f9eab985a9d28d1",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 119,
                  "codigo": "R119",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.0936",
                      "cantidadInicial": "100",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 25
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60029b6b",
                  "_rev": "1-0244751ad4a75f223dd022a08092e83a",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 123,
                  "codigo": "R123",
                  "rendimientoMaterial": "0.1000",
                  "rendimientoForro": "0.0833",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0200",
                      "cantidadInicial": "50",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0286",
                      "cantidadInicial": "35",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": "0.0000",
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.9685",
                      "cantidadInicial": "180",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 26
              },
              {
                "estilo": {
                  "_id": "07e40c5d5b9d552b83d9082e60029b3a",
                  "_rev": "1-912bbf49fd84f99c3ca57f7fc119ed65",
                  "linea": {
                    "_id": "07e40c5d5b9d552b83d9082e6001ffae",
                    "_rev": "1-fa464a21bd84a3ec0c7b66f318ada75a",
                    "nombre": "R",
                    "tacon": false,
                    "plantilla": {
                      "_id": "07e40c5d5b9d552b83d9082e6001f1d1",
                      "_rev": "1-8eb88baeaea6f00afb22f0f7488b4eec",
                      "nombre": "china",
                      "avillos": [
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
                          "_rev": "1-33358ec4023550fa089677837aa750b0",
                          "nombre": "carton con eva",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "pliegos",
                            "conversiones": [
                              {
                                "nombre": "pares en pliego",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en pliego",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                          "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                          "nombre": "pega amarilla",
                          "cantidad": "0.0100",
                          "cantidadInicial": "100",
                          "unidad": {
                            "nombre": "galones",
                            "conversiones": [
                              {
                                "nombre": "pares en galon",
                                "constante": null
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en galon",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        },
                        {
                          "_id": "07e40c5d5b9d552b83d9082e6000fc42",
                          "_rev": "1-1fe631135331b07e429008a6e292ed7c",
                          "nombre": "forro perla",
                          "cantidad": "0.0286",
                          "cantidadInicial": "35",
                          "unidad": {
                            "nombre": "yardas",
                            "conversiones": [
                              {
                                "nombre": "pares en yardas",
                                "constante": null
                              },
                              {
                                "nombre": "centimetros",
                                "constante": 0.010936132983377079
                              },
                              {
                                "nombre": "pulgadas",
                                "constante": 0.027777777777777776
                              }
                            ]
                          },
                          "colorSegunMaterial": false,
                          "unidadConversion": {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          "predeterminado": false,
                          "paraTacon": false
                        }
                      ]
                    },
                    "avillos": [
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b062",
                        "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                        "nombre": "royalty 300",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                        "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                        "nombre": "royalty 600",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "pliegos",
                          "conversiones": [
                            {
                              "nombre": "pares en pliego",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en pliego",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                        "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                        "nombre": "pega amarilla",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                        "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                        "nombre": "pega blanca",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "galones",
                          "conversiones": [
                            {
                              "nombre": "pares en galon",
                              "constante": null
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en galon",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      },
                      {
                        "_id": "07e40c5d5b9d552b83d9082e60011be5",
                        "_rev": "1-81a48495237f9723dcf8292eb390e542",
                        "nombre": "ahuantamedia",
                        "cantidad": 0,
                        "cantidadInicial": 0,
                        "unidad": {
                          "nombre": "yardas",
                          "conversiones": [
                            {
                              "nombre": "pares en yardas",
                              "constante": null
                            },
                            {
                              "nombre": "centimetros",
                              "constante": 0.010936132983377079
                            },
                            {
                              "nombre": "pulgadas",
                              "constante": 0.027777777777777776
                            }
                          ]
                        },
                        "colorSegunMaterial": false,
                        "unidadConversion": {
                          "nombre": "pares en yardas",
                          "constante": null
                        },
                        "predeterminado": false,
                        "paraTacon": false
                      }
                    ]
                  },
                  "correlativo": 121,
                  "codigo": "R121",
                  "rendimientoMaterial": "0.0667",
                  "rendimientoForro": "0.0500",
                  "avillos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b062",
                      "_rev": "1-dede68e5f241481ce33503b6cb22ff52",
                      "nombre": "royalty 300",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000b45c",
                      "_rev": "1-38f48c33a8188254cef5fa35fad67def",
                      "nombre": "royalty 600",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "unidad": {
                        "nombre": "pliegos",
                        "conversiones": [
                          {
                            "nombre": "pares en pliego",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en pliego",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
                      "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
                      "nombre": "pega amarilla",
                      "cantidad": "0.0133",
                      "cantidadInicial": "75",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
                      "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
                      "nombre": "pega blanca",
                      "cantidad": "0.0100",
                      "cantidadInicial": "100",
                      "unidad": {
                        "nombre": "galones",
                        "conversiones": [
                          {
                            "nombre": "pares en galon",
                            "constante": null
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en galon",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60011be5",
                      "_rev": "1-81a48495237f9723dcf8292eb390e542",
                      "nombre": "ahuantamedia",
                      "cantidad": "0.0167",
                      "cantidadInicial": "60",
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "pares en yardas",
                            "constante": null
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "colorSegunMaterial": false,
                      "unidadConversion": {
                        "nombre": "pares en yardas",
                        "constante": null
                      },
                      "predeterminado": false,
                      "paraTacon": false
                    }
                  ],
                  "adornos": [
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60002423",
                      "_rev": "1-4653b8e5df519330876484553e8316c0",
                      "nombre": "punteras R96",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60003086",
                      "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
                      "nombre": "punteras R120",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000351d",
                      "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
                      "nombre": "flor R122",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600041ec",
                      "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
                      "nombre": "girasol con repollo",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60004fda",
                      "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
                      "nombre": "remache 1,000",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600052b5",
                      "_rev": "1-8a10f6721a7daaff28879c2a83358145",
                      "nombre": "perlas remaches",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000560a",
                      "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
                      "nombre": "evillas de 3 puntos",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000606d",
                      "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
                      "nombre": "punteras R121",
                      "cantidad": "1.0000",
                      "cantidadInicial": "1",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60006ece",
                      "_rev": "1-7dd59c57c369802e3413387aa110e28d",
                      "nombre": "flor con repollo R123",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000750d",
                      "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
                      "nombre": "flores de ojitas",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600079c9",
                      "_rev": "1-59b03814471dda8b230288993f3c1021",
                      "nombre": "punteras R119",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600083fe",
                      "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
                      "nombre": "elastico",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "yardas",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088d6",
                      "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
                      "nombre": "remaches diamantes",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": false,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e600088e2",
                      "_rev": "2-4da34413925938ff509a1c81f908bc1b",
                      "nombre": "cola de raton",
                      "cantidad": "1.9685",
                      "cantidadInicial": "180",
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "yardas",
                        "conversiones": [
                          {
                            "nombre": "yardas",
                            "constante": 1
                          },
                          {
                            "nombre": "centimetros",
                            "constante": 0.010936132983377079
                          },
                          {
                            "nombre": "pulgadas",
                            "constante": 0.027777777777777776
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "centimetros",
                        "constante": 0.010936132983377079
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e60008deb",
                      "_rev": "1-d45897d3e3c17516fc4267d2fb83d8e7",
                      "nombre": "chonga R124",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    },
                    {
                      "_id": "07e40c5d5b9d552b83d9082e6000955a",
                      "_rev": "1-fb1ed0a79d61e677f96b0e8c093c3ae4",
                      "nombre": "punteras R95",
                      "cantidad": 0,
                      "cantidadInicial": 0,
                      "colorSegunMaterial": true,
                      "unidad": {
                        "nombre": "pares",
                        "conversiones": [
                          {
                            "nombre": "pares",
                            "constante": 1
                          }
                        ]
                      },
                      "unidadConversion": {
                        "nombre": "pares",
                        "constante": 1
                      }
                    }
                  ],
                  "img": null
                },
                "detalleMaterial": {
                  "material": {
                    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                    "nombre": "durasno",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gena",
                      "azul",
                      "corinto",
                      "beige",
                      "mostaza",
                      "uva",
                      "naranja",
                      "rosa vieja"
                    ]
                  },
                  "color": "negro"
                },
                "detalleTacon": {
                  "material": null,
                  "color": null
                },
                "detalleTallas": [
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012946",
                      "_rev": "1-b6d9adcd8707ce012e6a662efc23a2a6",
                      "nombre": "3"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60012b18",
                      "_rev": "1-7f1f0dda62209c5db0bd8645b46acd54",
                      "nombre": "4"
                    },
                    "cantidad": 2
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013237",
                      "_rev": "1-7ba795fd6878a03ba03836a6248e1abf",
                      "nombre": "5"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60013c50",
                      "_rev": "1-369f6c06796dd28d22a3d53ebc1ccf0f",
                      "nombre": "6"
                    },
                    "cantidad": 8
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600142e3",
                      "_rev": "1-726e88f684758e1108267e7089dea861",
                      "nombre": "7"
                    },
                    "cantidad": 6
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60014802",
                      "_rev": "1-b949a45fa1afa0c63700e799ead3610c",
                      "nombre": "8"
                    },
                    "cantidad": 3
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e600155db",
                      "_rev": "1-ee6c11b57ae6b0c6c1ceb34aa717f11d",
                      "nombre": "9"
                    },
                    "cantidad": 0
                  },
                  {
                    "talla": {
                      "_id": "07e40c5d5b9d552b83d9082e60015c95",
                      "_rev": "1-07438668ffb8320c24bb8f7e32e6c9a0",
                      "nombre": "40"
                    },
                    "cantidad": 0
                  }
                ],
                "horma": {
                  "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
                  "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
                  "nombre": "felipa",
                  "paraTacon": false
                },
                "detalleForro": {
                  "forro": {
                    "_id": "07e40c5d5b9d552b83d9082e60019c69",
                    "_rev": "1-f10adae14648b0c4d1c81e4f91a10139",
                    "nombre": "tricoth",
                    "defaultColor": "gris",
                    "colores": [
                      "negro",
                      "gris",
                      "beige"
                    ]
                  },
                  "color": "gris"
                },
                "detalleSuela": {
                  "suela": {
                    "_id": "07e40c5d5b9d552b83d9082e60022d66",
                    "_rev": "2-87d7391c6e96b9debcc28f452ac345af",
                    "nombre": "1122",
                    "defaultColor": "negro",
                    "colores": [
                      "negro",
                      "gun"
                    ]
                  },
                  "color": "negro"
                },
                "subtotal": 25
              }
            ],
            "isEditing": false,
            "isMoving": false,
            "total": 76
          }
        ],
        "listaDeCompras": {
          "adornos": [
            {
              "_id": "07e40c5d5b9d552b83d9082e600088e2",
              "_rev": "2-4da34413925938ff509a1c81f908bc1b",
              "nombre": "cola de raton durasno gena",
              "cantidad": 15.31,
              "cantidadInicial": "100",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600088e2",
              "_rev": "2-4da34413925938ff509a1c81f908bc1b",
              "nombre": "cola de raton durasno negro",
              "cantidad": 184.163,
              "cantidadInicial": "100",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600088e2",
              "_rev": "2-4da34413925938ff509a1c81f908bc1b",
              "nombre": "cola de raton durasno rosa vieja",
              "cantidad": 13.123,
              "cantidadInicial": "100",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600088e2",
              "_rev": "2-4da34413925938ff509a1c81f908bc1b",
              "nombre": "cola de raton pu beige",
              "cantidad": 39.37,
              "cantidadInicial": "100",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600088e2",
              "_rev": "2-4da34413925938ff509a1c81f908bc1b",
              "nombre": "cola de raton pu negro",
              "cantidad": 47.025,
              "cantidadInicial": "100",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600083fe",
              "_rev": "1-db9c7f3d4eec6e3222e59f3a4b402d57",
              "nombre": "elastico durasno negro",
              "cantidad": 3.981,
              "cantidadInicial": "28",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "yardas",
                    "constante": 1
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "centimetros",
                "constante": 0.010936132983377079
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000560a",
              "_rev": "1-bdb7bfb41df7f0f01d70e7b2d23c0f71",
              "nombre": "evillas de 3 puntos",
              "cantidad": 44,
              "cantidadInicial": "1",
              "colorSegunMaterial": false,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000351d",
              "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
              "nombre": "flor R122 durasno gena",
              "cantidad": 14,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000351d",
              "_rev": "1-3cf5c41bc96e39255858706417bdd4d1",
              "nombre": "flor R122 durasno negro",
              "cantidad": 20,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60006ece",
              "_rev": "1-7dd59c57c369802e3413387aa110e28d",
              "nombre": "flor con repollo R123 durasno negro",
              "cantidad": 26,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000750d",
              "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
              "nombre": "flores de ojitas pu corinto",
              "cantidad": 12,
              "cantidadInicial": "3",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000750d",
              "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
              "nombre": "flores de ojitas pu negro",
              "cantidad": 39,
              "cantidadInicial": "3",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000750d",
              "_rev": "1-ac4af114ab68bdde8208e22e6b2832b6",
              "nombre": "flores de ojitas pu rosado",
              "cantidad": 15,
              "cantidadInicial": "3",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600041ec",
              "_rev": "1-87a188dcb43bb76cc1acc5d31546c9bf",
              "nombre": "girasol con repollo durasno negro",
              "cantidad": 13,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600052b5",
              "_rev": "1-8a10f6721a7daaff28879c2a83358145",
              "nombre": "perlas remaches",
              "cantidad": 70,
              "cantidadInicial": "3",
              "colorSegunMaterial": false,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600079c9",
              "_rev": "1-59b03814471dda8b230288993f3c1021",
              "nombre": "punteras R119 durasno negro    0/[3],  8/[4-5],  14/[6-7],  3/[8-9]",
              "cantidad": 25,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 8,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 14,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 3,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60003086",
              "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
              "nombre": "punteras R120 durasno negro    0/[3],  0/[4-5],  10/[6-7],  0/[8-9]",
              "cantidad": 10,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 0,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 10,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 0,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60003086",
              "_rev": "2-fffd792aa4b4e0dff570d731c30ed180",
              "nombre": "punteras R120 durasno rosa vieja    0/[3],  4/[4-5],  8/[6-7],  0/[8-9]",
              "cantidad": 12,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 4,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 8,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 0,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000606d",
              "_rev": "1-08d2fcf0fd29cd750848b5f996f49789",
              "nombre": "punteras R121 durasno negro    0/[3],  8/[4-5],  14/[6-7],  3/[8-9]",
              "cantidad": 25,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 8,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 14,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 3,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60002423",
              "_rev": "1-4653b8e5df519330876484553e8316c0",
              "nombre": "punteras R96 pu beige    0/[3],  12/[4-5],  16/[6-7],  8/[8-9]",
              "cantidad": 36,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 12,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 16,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 8,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60002423",
              "_rev": "1-4653b8e5df519330876484553e8316c0",
              "nombre": "punteras R96 pu negro    0/[3],  14/[4-5],  20/[6-7],  9/[8-9]",
              "cantidad": 43,
              "cantidadInicial": "1",
              "colorSegunMaterial": true,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "punteras": [
                {
                  "cantidad": 0,
                  "categoria": "[3]"
                },
                {
                  "cantidad": 14,
                  "categoria": "[4-5]"
                },
                {
                  "cantidad": 20,
                  "categoria": "[6-7]"
                },
                {
                  "cantidad": 9,
                  "categoria": "[8-9]"
                }
              ]
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60004fda",
              "_rev": "1-e65b7f38b7756d0f0551121db0a194f3",
              "nombre": "remache 1,000",
              "cantidad": 13,
              "cantidadInicial": "1",
              "colorSegunMaterial": false,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600088d6",
              "_rev": "1-8ffdb219ae38d0bb742be3e52cc152cf",
              "nombre": "remaches diamantes",
              "cantidad": 110,
              "cantidadInicial": "5",
              "colorSegunMaterial": false,
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              }
            }
          ],
          "avillos": [
            {
              "_id": "07e40c5d5b9d552b83d9082e60011be5",
              "_rev": "1-81a48495237f9723dcf8292eb390e542",
              "nombre": "ahuantamedia",
              "cantidad": 5.313,
              "cantidadInicial": "60",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000d246",
              "_rev": "1-3f6ca847b1131b810c2c11f8fc8da036",
              "nombre": "cambrellon",
              "cantidad": 27,
              "cantidadInicial": "1",
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "predeterminado": false,
              "paraTacon": true
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000c5f9",
              "_rev": "1-33358ec4023550fa089677837aa750b0",
              "nombre": "carton con eva",
              "cantidad": 9.381,
              "cantidadInicial": "35",
              "unidad": {
                "nombre": "pliegos",
                "conversiones": [
                  {
                    "nombre": "pares en pliego",
                    "constante": null
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en pliego",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60010794",
              "_rev": "2-1f9ab4f0e67d48c1bc35e7e6384208d1",
              "nombre": "carton piedra",
              "cantidad": 0.397,
              "cantidadInicial": "68",
              "unidad": {
                "nombre": "pliegos",
                "conversiones": [
                  {
                    "nombre": "pares en pliego",
                    "constante": null
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en pliego",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": true
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000a52a",
              "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
              "nombre": "durasno para plantilla durasno negro",
              "cantidad": 1.618,
              "cantidadInicial": "15",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": true,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000a52a",
              "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
              "nombre": "durasno para plantilla pu corinto",
              "cantidad": 0.21,
              "cantidadInicial": "19",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": true,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000a52a",
              "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
              "nombre": "durasno para plantilla pu gena",
              "cantidad": 0.579,
              "cantidadInicial": "19",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": true,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000a52a",
              "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
              "nombre": "durasno para plantilla pu negro",
              "cantidad": 2.13,
              "cantidadInicial": "15",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": true,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000a52a",
              "_rev": "1-635bf1a838e5fb0e58158f798ceba469",
              "nombre": "durasno para plantilla pu rosado",
              "cantidad": 0.263,
              "cantidadInicial": "19",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": true,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000d58c",
              "_rev": "1-393b7967bb129a87989e2150a2efa9f3",
              "nombre": "evilla de 3 puntos",
              "cantidad": 27,
              "cantidadInicial": "1",
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000fc42",
              "_rev": "1-1fe631135331b07e429008a6e292ed7c",
              "nombre": "forro perla",
              "cantidad": 7.375,
              "cantidadInicial": "35",
              "unidad": {
                "nombre": "yardas",
                "conversiones": [
                  {
                    "nombre": "pares en yardas",
                    "constante": null
                  },
                  {
                    "nombre": "centimetros",
                    "constante": 0.010936132983377079
                  },
                  {
                    "nombre": "pulgadas",
                    "constante": 0.027777777777777776
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en yardas",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000e0ac",
              "_rev": "1-faaababf9ff03910d9bf6b9429a32352",
              "nombre": "pega amarilla",
              "cantidad": 8.243,
              "cantidadInicial": "75",
              "unidad": {
                "nombre": "galones",
                "conversiones": [
                  {
                    "nombre": "pares en galon",
                    "constante": null
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en galon",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000ec6a",
              "_rev": "1-8ad6248ad29cde6c259bf95b274ff909",
              "nombre": "pega blanca",
              "cantidad": 3.369,
              "cantidadInicial": "100",
              "unidad": {
                "nombre": "galones",
                "conversiones": [
                  {
                    "nombre": "pares en galon",
                    "constante": null
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en galon",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6000b45c",
              "_rev": "1-38f48c33a8188254cef5fa35fad67def",
              "nombre": "royalty 600",
              "cantidad": 0.668,
              "cantidadInicial": "60",
              "unidad": {
                "nombre": "pliegos",
                "conversiones": [
                  {
                    "nombre": "pares en pliego",
                    "constante": null
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares en pliego",
                "constante": null
              },
              "predeterminado": false,
              "paraTacon": false
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60010bfb",
              "_rev": "1-d88ab51277194072cce9b610851757c7",
              "nombre": "tacon",
              "cantidad": 27,
              "cantidadInicial": "1",
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "predeterminado": false,
              "paraTacon": true
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60010c3e",
              "_rev": "1-2655b2040186d6a61753daa920d52284",
              "nombre": "tornillo",
              "cantidad": 54,
              "cantidadInicial": "2",
              "unidad": {
                "nombre": "pares",
                "conversiones": [
                  {
                    "nombre": "pares",
                    "constante": 1
                  }
                ]
              },
              "colorSegunMaterial": false,
              "unidadConversion": {
                "nombre": "pares",
                "constante": 1
              },
              "predeterminado": false,
              "paraTacon": true
            }
          ],
          "suelas": [
            {
              "_id": "07e40c5d5b9d552b83d9082e60022d66gun",
              "nombre": "1122",
              "color": "gun",
              "detalle": [
                {
                  "nombre": "4",
                  "cantidad": 4
                },
                {
                  "nombre": "5",
                  "cantidad": 12
                },
                {
                  "nombre": "6",
                  "cantidad": 12
                },
                {
                  "nombre": "7",
                  "cantidad": 12
                },
                {
                  "nombre": "8",
                  "cantidad": 5
                },
                {
                  "nombre": "9",
                  "cantidad": 3
                },
                {
                  "nombre": "3",
                  "cantidad": 0
                },
                {
                  "nombre": "40",
                  "cantidad": 0
                }
              ],
              "total": 48
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60022d66negro",
              "nombre": "1122",
              "color": "negro",
              "detalle": [
                {
                  "nombre": "4",
                  "cantidad": 16
                },
                {
                  "nombre": "5",
                  "cantidad": 37
                },
                {
                  "nombre": "6",
                  "cantidad": 55
                },
                {
                  "nombre": "7",
                  "cantidad": 52
                },
                {
                  "nombre": "8",
                  "cantidad": 26
                },
                {
                  "nombre": "9",
                  "cantidad": 6
                },
                {
                  "nombre": "3",
                  "cantidad": 1
                },
                {
                  "nombre": "40",
                  "cantidad": 3
                }
              ],
              "total": 196
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e600235danegro",
              "nombre": "sueleta",
              "color": "negro",
              "detalle": [
                {
                  "nombre": "4",
                  "cantidad": 4
                },
                {
                  "nombre": "5",
                  "cantidad": 6
                },
                {
                  "nombre": "6",
                  "cantidad": 6
                },
                {
                  "nombre": "7",
                  "cantidad": 6
                },
                {
                  "nombre": "8",
                  "cantidad": 4
                },
                {
                  "nombre": "9",
                  "cantidad": 1
                },
                {
                  "nombre": "3",
                  "cantidad": 0
                },
                {
                  "nombre": "40",
                  "cantidad": 0
                }
              ],
              "total": 27
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60022b3ccrema",
              "nombre": "1158",
              "color": "crema",
              "detalle": [
                {
                  "nombre": "3",
                  "cantidad": 3
                },
                {
                  "nombre": "4",
                  "cantidad": 6
                },
                {
                  "nombre": "5",
                  "cantidad": 8
                },
                {
                  "nombre": "6",
                  "cantidad": 9
                },
                {
                  "nombre": "7",
                  "cantidad": 12
                },
                {
                  "nombre": "8",
                  "cantidad": 9
                },
                {
                  "nombre": "9",
                  "cantidad": 7
                },
                {
                  "nombre": "40",
                  "cantidad": 3
                }
              ],
              "total": 57
            }
          ],
          "tacones": [
            {
              "material": {
                "_id": "07e40c5d5b9d552b83d9082e6001da5d",
                "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
                "nombre": "durasno",
                "defaultColor": "negro",
                "colores": [
                  "negro",
                  "gena",
                  "azul",
                  "corinto",
                  "beige",
                  "mostaza",
                  "uva",
                  "naranja",
                  "rosa vieja"
                ]
              },
              "color": "negro",
              "cantidad": 0.1
            },
            {
              "material": {
                "_id": "07e40c5d5b9d552b83d9082e6001e681",
                "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
                "nombre": "pu",
                "defaultColor": "negro",
                "colores": [
                  "negro",
                  "gena",
                  "azul",
                  "beige",
                  "corinto",
                  "rosado"
                ]
              },
              "color": "negro",
              "cantidad": 0.1
            }
          ],
          "estilos": [
            {
              "codigo": "R96"
            },
            {
              "codigo": "R96"
            },
            {
              "codigo": "R120"
            },
            {
              "codigo": "R120"
            },
            {
              "codigo": "R122"
            },
            {
              "codigo": "R122"
            },
            {
              "codigo": "TA19"
            },
            {
              "codigo": "TA23"
            },
            {
              "codigo": "S2000"
            },
            {
              "codigo": "S2000"
            },
            {
              "codigo": "S75"
            },
            {
              "codigo": "BP6"
            },
            {
              "codigo": "R186"
            },
            {
              "codigo": "R90"
            },
            {
              "codigo": "S1000"
            },
            {
              "codigo": "S1000"
            },
            {
              "codigo": "S1000"
            },
            {
              "codigo": "R119"
            },
            {
              "codigo": "R123"
            },
            {
              "codigo": "R121"
            }
          ],
          "materiales": [
            {
              "_id": "07e40c5d5b9d552b83d9082e6001ca8enegro",
              "nombre": "charol",
              "color": "negro",
              "cantidad": 1.545
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001da5dnegro",
              "nombre": "durasno",
              "color": "negro",
              "cantidad": 11.837
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001da5drosa vieja",
              "nombre": "durasno",
              "color": "rosa vieja",
              "cantidad": 0.8
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001da5dgena",
              "nombre": "durasno",
              "color": "gena",
              "cantidad": 0.934
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001e681beige",
              "nombre": "pu",
              "color": "beige",
              "cantidad": 2.401
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001e681negro",
              "nombre": "pu",
              "color": "negro",
              "cantidad": 7.534
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001e681gena",
              "nombre": "pu",
              "color": "gena",
              "cantidad": 0.916
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001e681rosado",
              "nombre": "pu",
              "color": "rosado",
              "cantidad": 0.625
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e6001e681corinto",
              "nombre": "pu",
              "color": "corinto",
              "cantidad": 0.5
            }
          ],
          "forros": [
            {
              "_id": "07e40c5d5b9d552b83d9082e60019c69",
              "nombre": "forro tricoth",
              "color": "gris",
              "cantidad": 13.961
            },
            {
              "_id": "07e40c5d5b9d552b83d9082e60018d89",
              "nombre": "forro perla",
              "color": "perla",
              "cantidad": 7.845
            }
          ]
        }
      }
]