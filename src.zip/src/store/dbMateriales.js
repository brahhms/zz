[
  {
    "_id": "07e40c5d5b9d552b83d9082e6001ca8e",
    "_rev": "1-3457f600e12e510d240b3eae4a4b7c49",
    "nombre": "charol",
    "defaultColor": "negro",
    "colores": [
      "negro",
      "gena",
      "corinto",
      "rosa vieja",
      "azul",
      "rojo"
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001da5d",
    "_rev": "1-20d3b231ab85d21786fbc3d29e04b5f0",
    "nombre": "durasno",
    "defaultColor": "negro",
    "colores": [
      "negro",
      "gena",
      "azul",
      "corinto",
      "beige",
      "mostaza",
      "uva",
      "naranja",
      "rosa vieja"
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001e681",
    "_rev": "2-ddf56d0f4782b174a763a5cfac6ff9b8",
    "nombre": "pu",
    "defaultColor": "negro",
    "colores": [
      "negro",
      "gena",
      "azul",
      "beige",
      "corinto",
      "rosado"
    ]
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e600221be",
    "_rev": "1-18a3394d2dcd7adf87056f8d4e2a20ff",
    "nombre": "yute",
    "defaultColor": "beige",
    "colores": [
      "beige"
    ]
  }
]