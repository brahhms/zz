[
  {
    "_id": "07e40c5d5b9d552b83d9082e6001a6f2",
    "_rev": "1-0c7b93f0f9773f135964bb697e687bd3",
    "nombre": "sandalia",
    "paraTacon": false
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001b5a1",
    "_rev": "1-e0009a456ba1ed6c0abc1cbe5ab21487",
    "nombre": "felipa",
    "paraTacon": false
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001c1f0",
    "_rev": "1-6bc88db6bee3c9e703637f9ee99ad9cf",
    "nombre": "ow",
    "paraTacon": false
  },
  {
    "_id": "07e40c5d5b9d552b83d9082e6001c91b",
    "_rev": "2-3078117e56e48ef437288597b425ea86",
    "nombre": "plataforma 3152",
    "paraTacon": true
  }
]